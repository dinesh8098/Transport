<?php
session_start();
$s=$_SESSION["id"];
echo $s;